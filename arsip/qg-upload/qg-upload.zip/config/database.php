<?php
// config/database.php - Database Configuration

return [
    'server' => 'DCSQLSRV03.bps.go.id',
    'database' => 'QG_PROD',
    'username' => 'qgreadonly',
    'password' => 'A!rNeoHa55',
    'options' => [
        'CharacterSet' => 'UTF-8',
        'TrustServerCertificate' => true
    ]
]; 